import numpy as np

print "Number of payments", np.nper(0.10/12, -100, 9000)
