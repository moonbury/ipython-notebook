from __future__ import print_function
import numpy as np

print("Payment", np.pmt(0.01/12, 12 * 30, 10000000))
