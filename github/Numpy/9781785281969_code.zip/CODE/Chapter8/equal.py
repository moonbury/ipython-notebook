from __future__ import print_function
import numpy as np

print("Equal?", np.testing.assert_equal((1, 2), (1, 3)))
